@echo off

$env:SOLO_SAT_CHEAT="2"

python main.py
pause